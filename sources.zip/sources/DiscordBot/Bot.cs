﻿using System;
using System.IO;
using DSharpPlus;
using System.Text;
using System.Linq;
using Newtonsoft.Json;
using DSharpPlus.Entities;
using DSharpPlus.EventArgs;
using System.Threading.Tasks;
using DSharpPlus.CommandsNext;
using DSharpPlus.Interactivity;
using DSharpPlus.Interactivity.Enums;
using DSharpPlus.CommandsNext.Exceptions;
using DSharpPlus.Interactivity.Extensions;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using DSharpPlus.CommandsNext.Entities;
using DSharpPlus.CommandsNext.Converters;
using DSharpPlus.CommandsNext.Attributes;

namespace DiscordBot
{
    class Bot
    {
        public static EventId BotEventId = new EventId(1, "Яльга");
        static public DiscordClient bot;
        static private CommandsNextExtension commands;
        static public Dictionary<ulong, BotGuild> BotGuilds = new Dictionary<ulong, BotGuild>();
        static void Main()
        {
            RunBotAsync().ConfigureAwait(false).GetAwaiter().GetResult();
        }
        public struct ConfigJson
        {
            [JsonProperty("token")]
            public string Token { get; private set; }

            [JsonProperty("prefix")]
            public string CommandPrefix { get; private set; }
        }
        static private async Task RunBotAsync()
        {
            var json = "";
            using (var fs = File.OpenRead("config.json"))
            using (var sr = new StreamReader(fs, new UTF8Encoding(false)))
            json = await sr.ReadToEndAsync();
            var cfgjson = JsonConvert.DeserializeObject<ConfigJson>(json);
            var cfg = new DiscordConfiguration
            {
                Token = cfgjson.Token,
                TokenType = TokenType.Bot,
                AutoReconnect = true,
                MinimumLogLevel = LogLevel.Debug,
            };
            var commcdg = new CommandsNextConfiguration
            {
                StringPrefixes = new[] { cfgjson.CommandPrefix },
                EnableDms = false,
                EnableMentionPrefix = true
            };

            bot = new DiscordClient(cfg);
            commands = bot.UseCommandsNext(commcdg);
            commands.RegisterCommands<Commands>();
            commands.CommandExecuted += CommandExecuted;
            commands.CommandErrored += CommandErrored;
            bot.ClientErrored += ClientError;
            bot.GuildAvailable += GuildAvailable;
            
            //bot.GuildUnavailable += GuildUnavailable;
            bot.MessageCreated += MessageCreated;
            bot.MessageUpdated += MessageEdited;
            await bot.ConnectAsync();
            await Task.Delay(-1);
        }
        static private Task ClientError(DiscordClient sender, ClientErrorEventArgs e)
        {
            sender.Logger.LogError(BotEventId, e.Exception, $"Exception occured: {e.Exception.GetType()}: {e.Exception.Message}", DateTime.Now);
            return Task.CompletedTask;
        }
        static private Task GuildAvailable(DiscordClient sender, GuildCreateEventArgs e)
        {
            sender.Logger.LogInformation(BotEventId, e.Guild.Name, $"GUILD_AVAILABLE: {e.Guild.Name}", DateTime.Now);
            BotGuilds.Add(e.Guild.Id, new BotGuild());
            return Task.CompletedTask;
        }
        static private Task CommandExecuted(CommandsNextExtension sender, CommandExecutionEventArgs e)
        {
            e.Context.Client.Logger.LogInformation(BotEventId, $"{e.Context.User.Username} successfully executed '{e.Command.QualifiedName}'");
            return Task.CompletedTask;
        }
        static private Task CommandErrored(CommandsNextExtension sender, CommandErrorEventArgs e)
        {
            e.Context.Client.Logger.LogError(BotEventId, $"{e.Context.User.Username} errored while executed '{e.Command.QualifiedName}'");
            return Task.CompletedTask;
        }
        static private Task GuildUnavailable(DiscordClient sender, GuildCreateEventArgs e)
        {
            BotGuilds.Remove(e.Guild.Id);
            return Task.CompletedTask;
        }
        static private async Task MessageCreated(DiscordClient sender, MessageCreateEventArgs e)
        {
            if (!e.Author.IsBot)
            {
                DiscordMember z = await e.Guild.GetMemberAsync(e.Author.Id);
                if (!BotGuilds[e.Guild.Id].members.Keys.Contains(e.Author.Id))
                {
                    BotGuilds[e.Guild.Id].members.Add(e.Author.Id, new BotGuild.BotMember(e.Author.Username));
                }
                BotGuilds[e.Guild.Id].members[e.Author.Id].Messages += 1;
                if (!(e.Message.Content.StartsWith("!") && z.IsOwner) && IsContainsKeywords(BotGuilds[e.Guild.Id].ObsceneWords, e.Message.Content.ToLower()))
                {
                    if (BotGuilds[e.Guild.Id].IsBotCleaning)
                    {
                        await e.Message.DeleteAsync();
                    }
                    await z.SendMessageAsync($"Пожалуйста, не используйте нецензурную лексику и запрещённые на сервере {e.Guild.Name} слова. Список запрещённых слов и некоторую другую информацию можно узнать введя в чат \"!Настройки\".");
                    BotGuilds[e.Guild.Id].members[e.Author.Id].Mistakes += 1;
                    if (BotGuilds[e.Guild.Id].IsBotModerator && BotGuilds[e.Guild.Id].MaxMistakes <= BotGuilds[e.Guild.Id].members[e.Author.Id].Mistakes)
                    {
                        await z.BanAsync(0, $"Забанен(а) на сервере {e.Guild.Name} по причине употребления в речи запрещённых на нём слов.");
                        BotGuilds[e.Guild.Id].members[e.Author.Id].Mistakes = 0;
                        BotGuilds[e.Guild.Id].members[e.Author.Id].Complaints = new List<ulong>();
                    }
                }
                else if (!e.Message.Content.StartsWith("!") && BotGuilds[e.Guild.Id].IsBotChatting && IsContainsKeywords(BotGuilds[e.Guild.Id].GreetingWords, e.Message.Content.ToLower()))
                    {
                        Random r = new Random();
                        switch (r.Next(10))
                        {
                            case 0: await e.Message.RespondAsync($"О, привет, {e.Author.Username}."); break;
                            case 1: await e.Message.RespondAsync($"Здравствуй, {e.Author.Username}."); break;
                            case 2:
                                DateTime d = DateTime.Now;
                                if (d.Hour <= 4 || d.Hour > 21)
                                {
                                    await e.Message.RespondAsync($"Спокойная ночь, {e.Author.Username}, не правда ли?");
                                }
                                else if (d.Hour <= 9)
                                {
                                    await e.Message.RespondAsync($"*Зевок*\nУтречко, {e.Author.Username}.");
                                }
                                else if (d.Hour <= 17)
                                {
                                    await e.Message.RespondAsync($"Добрый день, {e.Author.Username}.");
                                }
                                else if (d.Hour > 17)
                                {
                                    await e.Message.RespondAsync($"Опять вечер, опять закат дня, {e.Author.Username}...");
                                }
                                break;
                            case 3: await e.Message.RespondAsync($"Салют, {e.Author.Username}."); break;
                            case 4: await e.Message.RespondAsync($"И тебе, {e.Author.Username}."); break;
                            case 5: await e.Message.RespondAsync($"Всем бобра... то есть добра."); break;
                            case 6: await e.Message.RespondAsync($"..."); break;
                            case 7: await e.Message.RespondAsync($"Доброго времени суток."); break;
                            case 8: await e.Message.RespondAsync($"*Зевок*\nЯ хочу спать."); break;
                            case 9: await e.Message.RespondAsync($"Пока."); break;
                        }
                    }
                else if (!e.Message.Content.StartsWith("!") && BotGuilds[e.Guild.Id].IsBotChatting && IsContainsKeywords(BotGuilds[e.Guild.Id].GoodbyeWords, e.Message.Content.ToLower()))
                    {
                        Random r = new Random();
                        switch (r.Next(10))
                        {
                            case 0: await e.Message.RespondAsync($"До встречи, {e.Author.Username}."); break;
                            case 1: await e.Message.RespondAsync($"Пока-пока, {e.Author.Username}."); break;
                            case 2:
                                DateTime d = DateTime.Now;
                                if (d.Hour <= 4 || d.Hour > 21)
                                {
                                    await e.Message.RespondAsync($"Спокойной ночи, {e.Author.Username}...");
                                }
                                else if (d.Hour <= 9)
                                {
                                    await e.Message.RespondAsync($"Доброго утра, {e.Author.Username}.");
                                }
                                else if (d.Hour <= 17)
                                {
                                    await e.Message.RespondAsync($"Счастливого дня, {e.Author.Username}.");
                                }
                                else if (d.Hour > 17)
                                {
                                    await e.Message.RespondAsync($"Хорошего вечера, {e.Author.Username}.");
                                }
                                break;
                            case 3: await e.Message.RespondAsync($"Ага, удачи..."); break;
                            case 4: await e.Message.RespondAsync($"Да-да, иди."); break;
                            case 5: await e.Message.RespondAsync($"До свидания."); break;
                            case 6: await e.Message.RespondAsync($"Пока."); break;
                            case 7: await e.Message.RespondAsync($"До завтра"); break;
                            case 8: await e.Message.RespondAsync($"Elfxyj...\nОй, не та раскладка.\nВ общем, пока."); break;
                            case 9: await e.Message.RespondAsync($"Не прощаюсь."); break;
                        }
                    }
                if (Bot.BotGuilds[e.Guild.Id].members[e.Author.Id].Complaints.Count >= Bot.BotGuilds[e.Guild.Id].MaxComplaints)
                {
                    await z.BanAsync(0, "Количество жалоб, поступившее на пользователя, превысило допустимые  на сервере границы.");
                    BotGuilds[e.Guild.Id].members[e.Author.Id].Mistakes = 0;
                    BotGuilds[e.Guild.Id].members[e.Author.Id].Complaints = new List<ulong>();
                }
            }
        }
        static private async Task MessageEdited(DiscordClient sender, MessageUpdateEventArgs e)
        {
            if (!e.Author.IsBot)
            {
                DiscordMember z = await e.Guild.GetMemberAsync(e.Author.Id);
                if (!BotGuilds[e.Guild.Id].members.Keys.Contains(e.Author.Id))
                {
                    BotGuilds[e.Guild.Id].members.Add(e.Author.Id, new BotGuild.BotMember(e.Author.Username));
                }
                BotGuilds[e.Guild.Id].members[e.Author.Id].Messages += 1;
                if (!(e.Message.Content.StartsWith("!") && z.IsOwner) && IsContainsKeywords(BotGuilds[e.Guild.Id].ObsceneWords, e.Message.Content.ToLower()))
                {
                    if (BotGuilds[e.Guild.Id].IsBotCleaning)
                    {
                        await e.Message.DeleteAsync();
                    }
                    await z.SendMessageAsync($"Пожалуйста, не используйте нецензурную лексику и запрещённые на сервере {e.Guild.Name} слова. Список запрещённых слов и некоторую другую информацию можно узнать введя в чат \"!Настройки\".");
                    BotGuilds[e.Guild.Id].members[e.Author.Id].Mistakes += 1;
                    if (BotGuilds[e.Guild.Id].IsBotModerator && BotGuilds[e.Guild.Id].MaxMistakes <= BotGuilds[e.Guild.Id].members[e.Author.Id].Mistakes)
                    {
                        await z.BanAsync(0, $"Забанен(а) на сервере {e.Guild.Name} по причине употребления в речи запрещённых на нём слов.");
                        BotGuilds[e.Guild.Id].members[e.Author.Id].Mistakes = 0;
                        BotGuilds[e.Guild.Id].members[e.Author.Id].Complaints = new List<ulong>();
                    }
                }
                else if (!e.Message.Content.StartsWith("!") && BotGuilds[e.Guild.Id].IsBotChatting && IsContainsKeywords(BotGuilds[e.Guild.Id].GreetingWords, e.Message.Content.ToLower()))
                {
                    Random r = new Random();
                    switch (r.Next(10))
                    {
                        case 0: await e.Message.RespondAsync($"О, привет, {e.Author.Username}."); break;
                        case 1: await e.Message.RespondAsync($"Здравствуй, {e.Author.Username}."); break;
                        case 2:
                            DateTime d = DateTime.Now;
                            if (d.Hour <= 4 || d.Hour > 21)
                            {
                                await e.Message.RespondAsync($"Спокойная ночь, {e.Author.Username}, не правда ли?");
                            }
                            else if (d.Hour <= 9)
                            {
                                await e.Message.RespondAsync($"*Зевок*\nУтречко, {e.Author.Username}.");
                            }
                            else if (d.Hour <= 17)
                            {
                                await e.Message.RespondAsync($"Добрый день, {e.Author.Username}.");
                            }
                            else if (d.Hour > 17)
                            {
                                await e.Message.RespondAsync($"Опять вечер, опять закат дня, {e.Author.Username}...");
                            }
                            break;
                        case 3: await e.Message.RespondAsync($"Салют, {e.Author.Username}."); break;
                        case 4: await e.Message.RespondAsync($"И тебе, {e.Author.Username}."); break;
                        case 5: await e.Message.RespondAsync($"Всем бобра... то есть добра."); break;
                        case 6: await e.Message.RespondAsync($"..."); break;
                        case 7: await e.Message.RespondAsync($"Доброго времени суток."); break;
                        case 8: await e.Message.RespondAsync($"*Зевок*\nЯ хочу спать."); break;
                        case 9: await e.Message.RespondAsync($"Пока."); break;
                    }
                }
                else if (!e.Message.Content.StartsWith("!") && BotGuilds[e.Guild.Id].IsBotChatting && IsContainsKeywords(BotGuilds[e.Guild.Id].GoodbyeWords, e.Message.Content.ToLower()))
                {
                    Random r = new Random();
                    switch (r.Next(10))
                    {
                        case 0: await e.Message.RespondAsync($"До встречи, {e.Author.Username}."); break;
                        case 1: await e.Message.RespondAsync($"Пока-пока, {e.Author.Username}."); break;
                        case 2:
                            DateTime d = DateTime.Now;
                            if (d.Hour <= 4 || d.Hour > 21)
                            {
                                await e.Message.RespondAsync($"Спокойной ночи, {e.Author.Username}...");
                            }
                            else if (d.Hour <= 9)
                            {
                                await e.Message.RespondAsync($"Доброго утра, {e.Author.Username}.");
                            }
                            else if (d.Hour <= 17)
                            {
                                await e.Message.RespondAsync($"Счастливого дня, {e.Author.Username}.");
                            }
                            else if (d.Hour > 17)
                            {
                                await e.Message.RespondAsync($"Хорошего вечера, {e.Author.Username}.");
                            }
                            break;
                        case 3: await e.Message.RespondAsync($"Ага, удачи..."); break;
                        case 4: await e.Message.RespondAsync($"Да-да, иди."); break;
                        case 5: await e.Message.RespondAsync($"До свидания."); break;
                        case 6: await e.Message.RespondAsync($"Пока."); break;
                        case 7: await e.Message.RespondAsync($"До завтра"); break;
                        case 8: await e.Message.RespondAsync($"Elfxyj...\nОй, не та раскладка.\nВ общем, пока."); break;
                        case 9: await e.Message.RespondAsync($"Не прощаюсь."); break;
                    }
                }
                if (Bot.BotGuilds[e.Guild.Id].members[e.Author.Id].Complaints.Count >= Bot.BotGuilds[e.Guild.Id].MaxComplaints)
                {
                    await z.BanAsync(0, "Количество жалоб, поступившее на пользователя, превысило допустимые  на сервере границы.");
                    BotGuilds[e.Guild.Id].members[e.Author.Id].Mistakes = 0;
                    BotGuilds[e.Guild.Id].members[e.Author.Id].Complaints = new List<ulong>();
                }
            }
        }
        public static bool IsContainsKeywords(Dictionary<char, List<string>> Keywords, string Message)
        {
            string[] words = Message.Split(new char[10] { ' ', ',', '.', '!', '?', '-', ':', ';', '\'', '\"' });
            for (int z = 0; z < words.Length; z++)
            {
                if (words[z] != "" && Keywords.ContainsKey(words[z][0]) && Keywords[words[z][0]].Contains(words[z]))
                {
                    return true;
                }
            }
            return false;
        }
    }
    
    public class Commands : BaseCommandModule
    {
        [Command("Калькулятор"), Description("Вычисляет некоторые выражения.\nВозможные арифметические действия:\n- \"+\" - сложение; (x + y)\n- \"-\" - вычитание; (x - y)\n- \"*\" - умножение; (x * y)\n- \"/\" - деление; (x / y)\n- \"^\" - возведение в степень; (x ^ y)\n- \"№\" - извлечение корня; (х№ у)\nЗаметьте, что пробелы между знаками арифметических действий и чисел обязательны.\nСкобки \"(\", \")\" ставятся слева или справа от чисел без пробела.\nВот пример ввода: 3№ ((а + b) * с) ^ d"), Aliases("=")]
        public async Task Calc(CommandContext ctx)
        {
            var embed = new DiscordEmbedBuilder { Title = "__Калькулятор__", Description = $"**{ctx.Message.Author.Username}**,\n\n{ctx.Message.Content.Substring(ctx.Message.Content.Split()[0].Length + 1)} = **{Calculator.CalcFromString(ctx.Message.Content.ToLower().Substring(ctx.Message.Content.Split()[0].Length + 1))}**.", Color = DiscordColor.White };
            await ctx.Message.DeleteAsync();
            await ctx.RespondAsync(embed: embed);
        }

        [Command("Переводчик_Морзе"), Description("Простенький переводчик на всем знакомую азбуку. Поддерживает только русский язык. Введите предложение на русском, чтобы получить вариант на морзянке; введите предложение на морзянке, чтобы получить его на русском. "), Aliases("М")]
        public async Task Morze(CommandContext ctx)
        {
            string s = ctx.Message.Content.Substring(ctx.Message.Content.Split(' ')[0].Length+1);
            string[] sh = s.Split(new char[] { ' ', '.', '-'});
            string shs = "";
            for (int i = 0; i < sh.Length; i++)
            {
                shs += sh[i];
            }
            if (shs != "")
            {
                var embed = new DiscordEmbedBuilder { Title = "__Азбука Морзе__", Description = $"**{ctx.Message.Author.Username}**,\n\n{s}\n**{MorseCode.RecycleToMorse(s)}**", Color = DiscordColor.White };
                await ctx.Message.DeleteAsync();
                await ctx.RespondAsync(embed: embed);
            }
            else
            {
                var embed = new DiscordEmbedBuilder { Title = "__Азбука Морзе__", Description = $"**{ctx.Message.Author.Username}**,\n\n**{MorseCode.RecycleFromMorse(s)}**\n{s}.", Color = DiscordColor.White };
                await ctx.Message.DeleteAsync();
                await ctx.RespondAsync(embed: embed);
            }
        }

        [Command("Рандомайзер"), Description("Генерирует случайные числа... а что вы ожидали?)\nПринимает аргументы X Y Z, где X - минимальное значение, Y - максимальное, а Z - количество возвращаемых значений"), Aliases("roll", "r", "р")]
        public async Task Rand(CommandContext ctx)
        {
            var embed = new DiscordEmbedBuilder { Title = "__Случайные числа__", Description = $"**{ctx.Message.Author.Username}**,\n\n{Randomizer.Random(ctx.Message.Content.ToLower().Substring(ctx.Message.Content.Split()[0].Length + 1))}.", Color = DiscordColor.White };
            await ctx.Message.DeleteAsync();
            await ctx.RespondAsync(embed: embed);
        }

        [Command("Настройки"), Description("От владельца сервера для изменения настроек принимает сообщения вида:\n!Настройки\n1. true (Бот будет банить участников сервера)\n2. 10 (Бот будет банить участников сервера после накопления ими 10-и заблокированных сообщений)\n3. 5 (Бот будет банить участников сервера при накоплении ими 5-и жалоб от других участников)\n4. true (Бот будет блокировать сообщения, содержащие слова из пункта 8 настроек)\n5. false (Бот не будет реагировать на сообщения, содержащие слова из пунктов 6 и 7 настроек)\n6. Слово№1,Слово№2,Слово№3(слова приветствия через запятую)\n7. Слово№1,Слово№2,Слово№3(слова прощания через запятую)\n8. Слово№1,Слово№2,Слово№3(нежелательные для употребления на сервере слова через запятую)\nДругие участники сервера могут посмотреть текущие настройки, введя \"!Настройки\"")]
        public async Task Settings(CommandContext ctx)
        {
            if (ctx.Message.Content != "!Настройки" && ctx.Member.IsOwner)
            {
                string[] settings = ctx.Message.Content.ToLower().Split("\n");
                if (settings[1] == "1. true")
                    Bot.BotGuilds[ctx.Guild.Id].IsBotModerator = true;
                else if (settings[1] == "1. false")
                    Bot.BotGuilds[ctx.Guild.Id].IsBotModerator = false;
                Bot.BotGuilds[ctx.Guild.Id].MaxComplaints = int.Parse(settings[2].Substring(3));
                Bot.BotGuilds[ctx.Guild.Id].MaxMistakes = int.Parse(settings[3].Substring(3));
                if (settings[4] == "4. true")
                    Bot.BotGuilds[ctx.Guild.Id].IsBotCleaning = true;
                else if (settings[4] == "4. false")
                    Bot.BotGuilds[ctx.Guild.Id].IsBotCleaning = false;
                if (settings[5] == "5. true")
                    Bot.BotGuilds[ctx.Guild.Id].IsBotChatting = true;
                else if (settings[5] == "5. false")
                    Bot.BotGuilds[ctx.Guild.Id].IsBotChatting = false;
                Bot.BotGuilds[ctx.Guild.Id].ChangeGreetingWords(settings[6].Substring(3).Split(','));
                Bot.BotGuilds[ctx.Guild.Id].ChangeGoodbyeWords(settings[7].Substring(3).Split(','));
                Bot.BotGuilds[ctx.Guild.Id].ChangeObsceneWords(settings[8].Substring(3).Split(','));
            }
            await ctx.Message.DeleteAsync();
            var embed = new DiscordEmbedBuilder 
            { 
                Title = "__Настройки__", 
                Description = $"1. Банить участников сервера: **{Bot.BotGuilds[ctx.Guild.Id].IsBotModerator}**\n2. Необходимое число жалоб на участника сервера для удаления этого участника: **{Bot.BotGuilds[ctx.Guild.Id].MaxComplaints}**\n3. Необходимое число проступков участника сервера для его удаления: **{Bot.BotGuilds[ctx.Guild.Id].MaxMistakes}**\n4. Будет ли бот удалять сообщения, содержащие нецензурную лексику: **{Bot.BotGuilds[ctx.Guild.Id].IsBotCleaning}**\n5. Будет ли бот отправлять обычные сообщения в чат: **{Bot.BotGuilds[ctx.Guild.Id].IsBotChatting}**\n6. Ключевые слова приветствия: {Bot.BotGuilds[ctx.Guild.Id].ShowGreetingWords()}\n7. Ключевые слова прощания: {Bot.BotGuilds[ctx.Guild.Id].ShowGoodbyeWords()}\n8. Ключевые слова, вызывающие удаление сообщения: {Bot.BotGuilds[ctx.Guild.Id].ShowObsceneWords()}", 
                Color = DiscordColor.Aquamarine 
            };
            await ctx.RespondAsync(embed: embed);
        }

        [Command("Профиль"), Description("Выводит некоторую информацию о участнике сервера, который использовал эту команду.")]
        public async Task Status(CommandContext ctx)
        {
            await ctx.Message.DeleteAsync();
            var embed = new DiscordEmbedBuilder { Title = $"__{ctx.Member.Username}__", Description = $"**1.** ID пользователя: **{ctx.Message.Author.Id}**;\n**2.** Количество написанных на сервере сообщений: ***{Bot.BotGuilds[ctx.Guild.Id].members[ctx.Message.Author.Id].Messages}***;\n**3.** Количество заблокированных сообщений: ***{Bot.BotGuilds[ctx.Guild.Id].members[ctx.Message.Author.Id].Mistakes}***/***{Bot.BotGuilds[ctx.Guild.Id].MaxMistakes}***;\n**4.** Количество жалоб на пользователя: ***{Bot.BotGuilds[ctx.Guild.Id].members[ctx.Message.Author.Id].Complaints.Count}***/***{Bot.BotGuilds[ctx.Guild.Id].MaxComplaints}***", Color = DiscordColor.SpringGreen };
            await ctx.RespondAsync(embed: embed);
        }

        [Command("Жалоба"), Description("При накоплении определённого количества жалоб, пользователь будет выгнан, как только проявит активность на сервере. Для использования укажите никнейм аккаунта пользователя: \"!Жалоба (Никнейм аккаунта)\"")]
        public async Task Complaint(CommandContext ctx)
        {
            string mess = ctx.Message.Content.Substring(7);
            await ctx.Message.DeleteAsync();
            for (int i = 0; i < Bot.BotGuilds[ctx.Guild.Id].members.Values.ToArray().Length; i++)
            {
                if (Bot.BotGuilds[ctx.Guild.Id].members.Values.ToArray()[i].Username == ctx.Message.Author.Username)
                {
                    if (Bot.BotGuilds[ctx.Guild.Id].members[Bot.BotGuilds[ctx.Guild.Id].members.Keys.ToArray()[i]].Complaints.Contains(ctx.Message.Author.Id))
                    {
                        await ctx.Member.SendMessageAsync("Вы уже отправляли жалобу на этого пользователя.");
                    }
                    else 
                    {
                        Bot.BotGuilds[ctx.Guild.Id].members[Bot.BotGuilds[ctx.Guild.Id].members.Keys.ToArray()[i]].Complaints.Add(ctx.Message.Author.Id);
                    }
                    break;
                }
            }
        }
    }
    class Randomizer
    {
        static private Random r = new Random();
        static public string Random(string s)
        {
            string[] g = s.Split();
            int i1 = 0;
            int i2 = 100;
            int i3 = 1;
            if (g.Length == 1)
            {
                i2 = int.Parse(g[0]);
            }
            else if (g.Length == 2)
            {
                i1 = int.Parse(g[0]);
                i2 = int.Parse(g[1]);
            }
            else if (g.Length == 3)
            {
                i1 = int.Parse(g[0]);
                i2 = int.Parse(g[1]);
                i3 = int.Parse(g[2]);
            }
            if (i1 >= i2)
            {
                return "Ошибка. Попробуйте увеличить нижний порог задаваемой вами области значений или уменьшить верхний.\nНе забудьте, сначала вводится нижний порог, потом - верхний.";
            }
            string answer = "";
            if (i3 > 100)
            {
                return "Вы задали сгенерировать более 100 случайных чисел, но хост-компьютер не вынесет столько... :cry: ";
            }
            for (int i = 1; i <= i3; i++)
            {
                answer += $"{r.Next(i1, i2 + 1)}, ";
            }
            return answer[0..^2];
        }
    }
    class MorseCode
    {
        static public string RecycleToMorse(string s)
        {
            string result = "";
            s = s.ToLower();
            for (int i = 0; i < s.Length; i++)
            {
                switch (s[i])
                {
                    case 'а': result += ".- "; break;
                    case 'б': result += "-... "; break;
                    case 'в': result += ".-- "; break;
                    case 'г': result += "--. "; break;
                    case 'д': result += "-.. "; break;
                    case 'е': result += ". "; break;
                    case 'ё': result += ". "; break;
                    case 'ж': result += "...- "; break;
                    case 'з': result += "--.. "; break;
                    case 'и': result += ".. "; break;
                    case 'й': result += ".--- "; break;
                    case 'к': result += "-.- "; break;
                    case 'л': result += ".-.. "; break;
                    case 'м': result += "-- "; break;
                    case 'н': result += "-. "; break;
                    case 'о': result += "--- "; break;
                    case 'п': result += ".--. "; break;
                    case 'р': result += ".-. "; break;
                    case 'с': result += "... "; break;
                    case 'т': result += "- "; break;
                    case 'у': result += "..- "; break;
                    case 'ф': result += "..-. "; break;
                    case 'х': result += ".... "; break;
                    case 'ц': result += "-.-. "; break;
                    case 'ч': result += "---. "; break;
                    case 'ш': result += "---- "; break;
                    case 'щ': result += "--.- "; break;
                    case 'ъ': result += "--.-- "; break;
                    case 'ы': result += "-.-- "; break;
                    case 'ь': result += "-..- "; break;
                    case 'э': result += "..-.. "; break;
                    case 'ю': result += "..-- "; break;
                    case 'я': result += ".-.- "; break;
                    case '1': result += ".---- "; break;
                    case '2': result += "..--- "; break;
                    case '3': result += "...-- "; break;
                    case '4': result += "....- "; break;
                    case '5': result += "..... "; break;
                    case '6': result += "-.... "; break;
                    case '7': result += "--... "; break;
                    case '8': result += "---.. "; break;
                    case '9': result += "----. "; break;
                    case '0': result += "----- "; break;
                    case '.': result += "...... "; break;
                    case ',': result += ".-.-.- "; break;
                    case '!': result += "--..-- "; break;
                    case '?': result += "..--.. "; break;
                    case '\'': result += ".----. "; break;
                    case '\"': result += ".-..-. "; break;
                    case ';': result += "-.-.-. "; break;
                    case ':': result += "---... "; break;
                    case '-': result += "-....- "; break;
                    case '+': result += ".-.-. "; break;
                    case '=': result += "-...- "; break;
                    case '_': result += "..--.- "; break;
                    case '/': result += "-..-. "; break;
                    case '(': result += "-.--.- "; break;
                    case ')': result += "-.--.- "; break;
                    case '&': result += ".-... "; break;
                    case '$': result += "...-..- "; break;
                    case '@': result += ".--.-. "; break;
                    case ' ': break;
                    default: result += "........ "; break;
                }
            }
            return result;
        }
        static public string RecycleFromMorse(string s)
        {
            string result = "";
            for (int i = 0; i < s.Length; i++)
            {
                if (IsChars(s[i], "*•"))
                {
                    result += ".";
                }
                else if (IsChars(s[i], "_−"))
                {
                    result += "-";
                }
                else
                {
                    result += s[i];
                }
            }
            s = result;
            result = "";
            string[] str = s.Split();
            for (int i = 0; i < str.Length; i++)
            {
                switch (str[i])
                {
                    case ".-": result += 'а'; break;
                    case "-...": result += 'б'; break;
                    case ".--": result += 'в'; break;
                    case "--.": result += 'г'; break;
                    case "-..": result += 'д'; break;
                    case ".": result += 'е'; break;
                    case "...-": result += 'ж'; break;
                    case "--..": result += 'з'; break;
                    case "..": result += 'и'; break;
                    case ".---": result += 'й'; break;
                    case "-.-": result += 'к'; break;
                    case ".-..": result += 'л'; break;
                    case "--": result += 'м'; break;
                    case "-.": result += 'н'; break;
                    case "---": result += 'о'; break;
                    case ".--.": result += 'п'; break;
                    case ".-.": result += 'р'; break;
                    case "...": result += 'с'; break;
                    case "-": result += 'т'; break;
                    case "..-": result += 'у'; break;
                    case "..-.": result += 'ф'; break;
                    case "....": result += 'х'; break;
                    case "-.-.": result += 'ц'; break;
                    case "---.": result += 'ч'; break;
                    case "----": result += 'ш'; break;
                    case "--.-": result += 'щ'; break;
                    case "--.--": result += 'ъ'; break;
                    case "-.--": result += 'ы'; break;
                    case "-..-": result += 'ь'; break;
                    case "..-..": result += 'э'; break;
                    case "..--": result += 'ю'; break;
                    case ".-.-": result += 'я'; break;
                    case ".----": result += '1'; break;
                    case "..---": result += '2'; break;
                    case "...--": result += '3'; break;
                    case "....-": result += '4'; break;
                    case ".....": result += '5'; break;
                    case "-....": result += '6'; break;
                    case "--...": result += '7'; break;
                    case "---..": result += '8'; break;
                    case "----.": result += '9'; break;
                    case "-----": result += '0'; break;
                    case "......": result += '.'; break;
                    case ".-.-.-": result += ','; break;
                    case "--..--": result += '!'; break;
                    case "..--..": result += '?'; break;
                    case ".----.": result += '\''; break;
                    case ".-..-.": result += '\"'; break;
                    case "-.-.-.": result += ';'; break;
                    case "---...": result += ':'; break;
                    case "-....-": result += '-'; break;
                    case ".-.-.": result += '+'; break;
                    case "-...-": result += '='; break;
                    case "..--.-": result += '_'; break;
                    case "-..-.": result += '/'; break;
                    case "-.--.-": result += '('; break;
                    case ".-...": result += '&'; break;
                    case "...-..-": result += '$'; break;
                    case ".--.-.": result += '@'; break;
                    case "........": result += " ошибка "; break;
                }
            }
            return result;
        }
        static private bool IsChars(char a, string s)
        {
            for (int i = 0; i < s.Length; i++)
            {
                if (a == s[i])
                {
                    return true;
                }
            }
            return false;
        }
    }
    class Calculator
    {
        public static string CalcFromString(string s)
        {
            string s1 = "";
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == '.')
                {
                    s1 += ',';
                }
                else
                {
                    s1 += s[i];
                }
            }
            s = s1;
            while (s.Contains('('))
            {
                string active = "";
                int index1 = 0;
                int index2 = 0;
                for (int i = 0; i < s.Length; i++)
                {
                    if (s[i] == '(')
                    {
                        index1 = i;
                    }
                    else if (s[i] == ')')
                    {
                        index2 = i;
                        break;
                    }
                }
                for (int i = index1 + 1; i < index2; i++)
                {
                    active += s[i];
                }
                active = Calcl(active);
                s = $"{s.Substring(0, index1)}{active}{s.Substring(index2 + 1)}";
            }
            s = Calcl(s);
            return s;
        }
        static private string Calcl(string s)
        {
            List<string> L = new List<string>(s.Split(' '));
            for (int i = 0; i < L.Count; i++)
            {
                if (L[i] == "^")
                {
                    L[i] = Math.Pow(double.Parse(L[i - 1]), double.Parse(L[i + 1])).ToString();
                    L.RemoveAt(i + 1);
                    L.RemoveAt(i - 1);
                    i--;
                }
                else if (L[i].Contains("№"))
                {
                    L[i] = Math.Pow(double.Parse(L[i + 1]), 1 / double.Parse(L[i].Substring(0, L[i].Length - 1))).ToString();
                    L.RemoveAt(i + 1);
                }
            }

            for (int i = 0; i < L.Count; i++)
            {
                if (L[i] == "*")
                {
                    L[i] = (decimal.Parse(L[i - 1]) * decimal.Parse(L[i + 1])).ToString();
                    L.RemoveAt(i + 1);
                    L.RemoveAt(i - 1);
                    i--;
                }
                else if (L[i] == "/")
                {
                    L[i] = (decimal.Parse(L[i - 1]) / decimal.Parse(L[i + 1])).ToString();
                    L.RemoveAt(i + 1);
                    L.RemoveAt(i - 1);
                    i--;
                }
            }

            for (int i = 0; i < L.Count; i++)
            {
                if (L[i] == "+")
                {
                    L[i] = (decimal.Parse(L[i - 1]) + decimal.Parse(L[i + 1])).ToString();
                    L.RemoveAt(i + 1);
                    L.RemoveAt(i - 1);
                    i--;
                }
                else if (L[i] == "-")
                {
                    L[i] = (decimal.Parse(L[i - 1]) - decimal.Parse(L[i + 1])).ToString();
                    L.RemoveAt(i + 1);
                    L.RemoveAt(i - 1);
                    i--;
                }
            }
            return L[0];
        }
    }
    class BotGuild
    {
        public Dictionary<char, List<string>> GreetingWords = new Dictionary<char, List<string>>();
        public Dictionary<char, List<string>> GoodbyeWords = new Dictionary<char, List<string>>();
        public Dictionary<char, List<string>> ObsceneWords = new Dictionary<char, List<string>>();
        public Dictionary<ulong, BotMember> members = new Dictionary<ulong, BotMember>();
        public void ChangeGreetingWords(string[] words)
        {
            GreetingWords = new Dictionary<char, List<string>>();
            for (int i = 0; i < words.Length; i++)
            {
                if (!GreetingWords.Keys.ToArray().Contains(words[i][0]))
                {
                    GreetingWords.Add(words[i][0], new List<string>(0));
                }
                if (!GreetingWords[words[i][0]].Contains(words[i]))
                {
                    GreetingWords[words[i][0]].Add(words[i]);
                }
            }
        }
        public void ChangeGoodbyeWords(string[] words)
        {
            GoodbyeWords = new Dictionary<char, List<string>>();
            for (int i = 0; i < words.Length; i++)
            {
                if (!GoodbyeWords.Keys.ToArray().Contains(words[i][0]))
                {
                    GoodbyeWords.Add(words[i][0], new List<string>(0));
                }
                if (!GoodbyeWords[words[i][0]].Contains(words[i]))
                {
                    GoodbyeWords[words[i][0]].Add(words[i]);
                }
            }
        }
        public void ChangeObsceneWords(string[] words)
        {
            ObsceneWords = new Dictionary<char, List<string>>();
            for (int i = 0; i < words.Length; i++)
            {
                if (!ObsceneWords.Keys.ToArray().Contains(words[i][0]))
                {
                    ObsceneWords.Add(words[i][0], new List<string>(0));
                }
                if (!ObsceneWords[words[i][0]].Contains(words[i]))
                {
                    ObsceneWords[words[i][0]].Add(words[i]);
                }
            }
        }
        public string ShowGreetingWords()
        {
            string answer = "";
            for (int i = 0; i < GreetingWords.Values.ToArray().Length; i++)
            {
                for (int j = 0; j < GreetingWords.Values.ToArray()[i].Count; j++)
                {
                    answer += GreetingWords.Values.ToArray()[i][j] + ",";
                }
            }
            return answer;
        }
        public string ShowGoodbyeWords()
        {
            string answer = "";
            for (int i = 0; i < GoodbyeWords.Values.ToArray().Length; i++)
            {
                for (int j = 0; j < GoodbyeWords.Values.ToArray()[i].Count; j++)
                {
                    answer += GoodbyeWords.Values.ToArray()[i][j] + ",";
                }
            }
            return answer;
        }
        public string ShowObsceneWords()
        {
            string answer = "";
            for (int i = 0; i < ObsceneWords.Values.ToArray().Length; i++)
            {
                for (int j = 0; j < ObsceneWords.Values.ToArray()[i].Count; j++)
                {
                    answer += ObsceneWords.Values.ToArray()[i][j] + ",";
                }
            }
            return answer;
        }
        public bool IsBotChatting = false;
        public bool IsBotCleaning = true;
        public bool IsBotModerator = false;
        public int MaxMistakes = 10;
        public int MaxComplaints = 5;

        public BotGuild()
        {
        }
        public class BotMember
        {
            public string Username;
            public int Mistakes = 0;
            public ulong Messages = 0;
            public List<ulong> Complaints = new List<ulong>();
            public BotMember(string name)
            {
                Username = name;
            }
        }
    }
}

